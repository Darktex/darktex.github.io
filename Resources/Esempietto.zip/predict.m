function [result] = predict(X, y, theta)

	n = size(theta, 1) - 1 % number of features. Theta is n+1
	while 1

		choice = menu('', 'Predict', 'Exit')

		if choice == 1
			newX = input('Insert house size: ');
			
			example = [1 newX];
			if (n > 2) % then we are using the smart classifier. Create high dim features
				for i=2:n
				A = example(:, 2).^i;
				example = [example A];
				end
			end
			result = example * theta;

			fprintf(['Predicted price: $%f\n'], result);

		end


		if choice == 2 
			break;
		end


	end



end