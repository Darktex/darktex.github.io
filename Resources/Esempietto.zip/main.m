%% Talk Cassini. Interactive linear regressor


%% Init
clear ; close all; clc

X = [1 0];
y = 0;
theta = zeros(0);

% 

while 1
	choice = menu('Choose what to do: ', 'Training', 'Predict', 'Plot');

	if choice == 1 
		[X y theta] = train(X, y, 10^30); % lambda = 1;
	end

	if choice == 2
		theta = theta
		predict(X, y, theta);
	end

	if choice == 3
		theta
		plotData(X(:, 2), y);
		pause
		hold on; % keep previous plot visible
		plot(X(:,2), X*theta, '-')
		legend('Training data', 'Linear regression')
		hold off % don't overlay any more plots on this figure
	end
end