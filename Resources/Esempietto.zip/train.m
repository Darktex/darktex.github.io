function [X, y, theta] = train(X, y)

	

	while 1
		m = size(X, 1); % number of examples so far
		theta = zeros(2, 1);
		choice = menu('', 'Insert data point', 'Get examples from file', 'Exit')

		if choice == 1
			newX = input('Insert house size: ');
			newY = input('Insert price: ');
			X = [X; 1 newX];
			y = [y; newY];
		end

		if choice == 2
			data = load('exampleData.txt');
			
			newX = data(:, 1);
			newY = data(:, 2);

			m = length(newY); % number of new training examples

			newX = [ones(m, 1) newX];
			X = [X; newX];
			y = [y; newY];
		end


		if choice == 3 
			if m == 0
				break;
			end
			theta = pinv(X'*X)*X'*y;
			break;
		end


	end

end